package com.example.mantenimientodbfirebase;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.sql.Array;
import java.util.ArrayList;
import java.util.HashMap;

public class ListaOrdenes extends AppCompatActivity {
    Button nuevaOrden;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_ordenes);

        nuevaOrden = findViewById(R.id.btnNuevaOrden);
        ListView listView = findViewById(R.id.listaOrdenesTrabajo);

        nuevaOrden.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
            }
        });

        //Get Servicios
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        //String diapositivo = FirebaseAuth.getInstance().getCurrentName(),getId();
        DatabaseReference myRef = database.getReference("servicios");
        myRef.get().addOnCanceledListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()){
                    Log.e("firebase", "Error getting data", task.getException());
                }
                else {
                    Log.d("firebase", String.valueOf(task.getResult().getValue()));
                    ArrayList<HashMap<String, String>> listaServicios = new ArrayList<>();
                    for (DataSnapshot ds : task.getResult().getChildren()){
                        HashMap<String, String> servicio = new HashMap<>();
                        servicio.put("id", ds.child("id").getValue().toString());
                        servicio.put("lugar", ds.child("lugar").getValue().toString());
                        servicio.put("descripcion", ds.child("descripcion").getValue().toString());
                    }
                }
            }
        });
    }
}
