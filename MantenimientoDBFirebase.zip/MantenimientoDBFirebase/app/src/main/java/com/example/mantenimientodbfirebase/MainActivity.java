package com.example.mantenimientodbfirebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    //Declaramos nuestros objetos JAVA asociando nuestros View
    EditText etLugar, etDescripcion;
    Button btnGuardar;

    //Variable auxiliar para simular un AUTO_INCREMENT
    long ultimoID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Inicializamos nuestros elementos de vista
        etLugar = findViewById(R.id.etLugar);
        etDescripcion = findViewById(R.id.etDescripcion);
        btnGuardar = findViewById(R.id.btnGuardar);

        //Capturamos el evento de click sopbre el boton
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Creamos instancia (conexion) a nuestra base de datos
                FirebaseDatabase database = FirebaseDatabase.getInstance();

                //Indicamos el nombre de la "tabla" (nodo) sobre el que vamos a trabajar
                DatabaseReference myRef = database.getReference("servicios");

                //Contamos los nodos existentes para simular el autoincremento
                myRef.addValueEventListener(new ValueEventListener(){

                    @Override
                    public void onDataChange(DataSnapshot snapshot){
                        if(snapshot.exists()){
                            ultimoID = (snapshot.getChildrenCount());
                        }
                    }
                    @Override
                    public void onCancelled(DatabaseError error){

                    }
                });

                String id, lugar, descripcion;
                lugar = etLugar.getText().toString();
                descripcion = etDescripcion.getText().toString();

                id = String.valueOf(ultimoID + 1);
                Ordenes orden = new Ordenes(id, lugar, descripcion);
                myRef.child(id).setValue(orden);
            }
        });
    }
}