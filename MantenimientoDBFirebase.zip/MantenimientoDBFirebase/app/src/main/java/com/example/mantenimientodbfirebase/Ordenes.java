package com.example.mantenimientodbfirebase;

public class Ordenes {
    private String ID;
    private String IDEdificio;
    private String Descripcion;

    public Ordenes(String ID, String IDEdificio, String Descripcion){
        this.ID = ID;
        this.IDEdificio = IDEdificio;
        this.Descripcion = Descripcion;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getIDEdificio() {
        return IDEdificio;
    }

    public void setIDEdificio(String IDEdificio) {
        this.IDEdificio = IDEdificio;
    }
    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }
}
